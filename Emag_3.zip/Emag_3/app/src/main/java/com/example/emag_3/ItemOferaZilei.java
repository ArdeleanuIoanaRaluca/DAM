package com.example.emag_3;

public class ItemOferaZilei {
    private String denumire;
    private String stoc;
    private String livator;
    private String detalii;
    private String pret;

    public ItemOferaZilei(String denumire, String stoc, String livator, String detalii, String pret) {
        this.denumire = denumire;
        this.stoc = stoc;
        this.livator = livator;
        this.detalii = detalii;
        this.pret = pret;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public String getStoc() {
        return stoc;
    }

    public void setStoc(String stoc) {
        this.stoc = stoc;
    }

    public String getLivator() {
        return livator;
    }

    public void setLivator(String livator) {
        this.livator = livator;
    }

    public String getDetalii() {
        return detalii;
    }

    public void setDetalii(String detalii) {
        this.detalii = detalii;
    }

    public String getPret() {
        return pret;
    }

    public void setPret(String pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return "ItemOferaZilei{" +
                "denumire='" + denumire + '\'' +
                ", stoc='" + stoc + '\'' +
                ", livator='" + livator + '\'' +
                ", detalii='" + detalii + '\'' +
                ", pret=" + pret +
                '}';
    }
}
