package com.example.emag_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class OfertaZilei extends AppCompatActivity {

    ListView listView;
    private ItemOferaZileiAdapter itemOferaZileiAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oferta_zilei);
        listView=findViewById(R.id.listView);
        itemOferaZileiAdapter= new ItemOferaZileiAdapter(getList());
        listView.setAdapter(itemOferaZileiAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Random r = new Random(1);
                int alegere=r.nextInt();

                if(alegere%2==0)
                {
                    itemOferaZileiAdapter.updateList(getList());
                } else
                    itemOferaZileiAdapter.updateList(getListMedicamente());


            }
        });
    }





    private List<ItemOferaZilei> getList()
    {
        ArrayList<ItemOferaZilei> lista= new ArrayList<>();

        ItemOferaZilei item1= new ItemOferaZilei("Set 100 Manusi Latex Pudrate Dolphin, Marime M","In stoc","Livrat de: eMAG","-15% extra","49,99 lei");
        ItemOferaZilei item2= new ItemOferaZilei("Alcool sanitar Dora, 70%, 500ML","In stoc","Livrat de: Clinica Medicala","-15% extra","5,99 lei");
        ItemOferaZilei item3= new ItemOferaZilei("Pulsoximetru digital de deget JUMPER JPD-500B","In stoc","Livrat de: eMAG","-15% extra","78.99 lei");
        ItemOferaZilei item4= new ItemOferaZilei("Set 50 bucati Masti medicale faciale, de unica folosinta, nesterile,tip II, Negru","In stoc","Livrat de: Farmec","-15% extra","17,99 lei" );

        lista.add(item1);
        lista.add(item2);
        lista.add(item3);
        lista.add(item4);
        return lista;


    }


    private List<ItemOferaZilei> getListMedicamente()
    {
        ArrayList<ItemOferaZilei> listaMedicamnte= new ArrayList<>();
        ItemOferaZilei item1= new ItemOferaZilei("Supliment alimentar Zinc si Vitamina D3 Immuno C Solaray, 30 capsule Secom","In stoc","Livrat de: eMAG","-15% extra","26,99 lei");
        ItemOferaZilei item2= new ItemOferaZilei("Supliment alimentar Vitamin D3 2000UI Nature's Way, Secom 120 capsule moi","In stoc","Livrat de: eMAG","-15% extra","36,99 lei");
        ItemOferaZilei item3= new ItemOferaZilei("Pestisori gumati Omega 3 Moller's, cu aroma de lamaie verde si capsune, 36 jeleuri","In stoc","Livrat de: eMAG","-15% extra","45,99 lei");
        ItemOferaZilei item4= new ItemOferaZilei("Supliment alimentar Neuro Optimizer Jarrow Formulas, Secom 60 capsule","In stoc","Livrat de: Farmec","-15% extra","110 lei" );

        listaMedicamnte.add(item1);
        listaMedicamnte.add(item2);
        listaMedicamnte.add(item3);
        listaMedicamnte.add(item4);



        return listaMedicamnte;
    }
    }
