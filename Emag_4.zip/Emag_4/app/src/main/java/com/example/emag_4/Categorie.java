package com.example.emag_4;

public class Categorie {

    String denumire;

    public Categorie() {
    }

    public Categorie(String denumire) {
        this.denumire = denumire;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    @Override
    public String toString() {
        return "Categorie{" +
                "denumire='" + denumire + '\'' +
                '}';
    }
}
