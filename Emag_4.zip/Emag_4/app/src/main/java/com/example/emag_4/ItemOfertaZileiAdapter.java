package com.example.emag_4;

import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ItemOfertaZileiAdapter extends  BaseAdapter {

    private Image imgProdus;

    private List<ItemOfertaZilei> listaOferte=new ArrayList<>();

    public ItemOfertaZileiAdapter(List<ItemOfertaZilei> listaOferte) {
        this.listaOferte = listaOferte;
    }

    @Override
    public int getCount() {
        return listaOferte.size();
    }

    @Override
    public ItemOfertaZilei getItem(int i) {
        return listaOferte.get(i);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int pos, View view, ViewGroup viewGroup) {
        LayoutInflater inflater=LayoutInflater.from(viewGroup.getContext());
        View view1= inflater.inflate(R.layout.activity_item_oferta_zilei,viewGroup, false);
        TextView textViewDenumire= view1.findViewById(R.id.textViewDenumire);
        TextView textViewStoc= view1.findViewById(R.id.textViewStoc);
        TextView textViewLivrator= view1.findViewById(R.id.textViewLivrator);
        TextView textViewDetalii= view1.findViewById(R.id.textViewDetalii);
        TextView textViewPret= view1.findViewById(R.id.textViewPret);

        ItemOfertaZilei temp= listaOferte.get(pos);
        textViewDenumire.setText(temp.getDenumire());
        textViewStoc.setText(temp.getStoc());
        textViewLivrator.setText(temp.getLivator());
        textViewDetalii.setText(temp.getDetalii());
        textViewPret.setText(temp.getPret()+"");


        return view1;

    }

    public void updateList(List<ItemOfertaZilei> lista)
    {
        listaOferte.clear();
        listaOferte.addAll(lista);

        notifyDataSetChanged();
    }
}