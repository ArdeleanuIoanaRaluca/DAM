package com.example.emag_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class OfertaZilei extends AppCompatActivity {

    ListView listView;
    private ItemOfertaZileiAdapter itemOferaZileiAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oferta_zilei);
        listView=findViewById(R.id.listView);
        itemOferaZileiAdapter= new ItemOfertaZileiAdapter(getList());
        listView.setAdapter(itemOferaZileiAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Random r = new Random(1);
                int alegere=r.nextInt();

                if(alegere%2==0)
                {
                    itemOferaZileiAdapter.updateList(getList());
                } else
                    itemOferaZileiAdapter.updateList(getListMedicamente());


            }
        });
    }





    private List<ItemOfertaZilei> getList()
    {
        ArrayList<ItemOfertaZilei> lista= new ArrayList<>();

        ItemOfertaZilei item1= new ItemOfertaZilei("Set 100 Manusi Latex Pudrate Dolphin, Marime M","In stoc","Livrat de: eMAG","-15% extra","49,99 lei");
        ItemOfertaZilei item2= new ItemOfertaZilei("Alcool sanitar Dora, 70%, 500ML","In stoc","Livrat de: Clinica Medicala","-15% extra","5,99 lei");
        ItemOfertaZilei item3= new ItemOfertaZilei("Pulsoximetru digital de deget JUMPER JPD-500B","In stoc","Livrat de: eMAG","-15% extra","78.99 lei");
        ItemOfertaZilei item4= new ItemOfertaZilei("Set 50 bucati Masti medicale faciale, de unica folosinta, nesterile,tip II, Negru","In stoc","Livrat de: Farmec","-15% extra","17,99 lei" );

        lista.add(item1);
        lista.add(item2);
        lista.add(item3);
        lista.add(item4);
        return lista;


    }


    private List<ItemOfertaZilei> getListMedicamente()
    {
        ArrayList<ItemOfertaZilei> listaMedicamnte= new ArrayList<>();
        ItemOfertaZilei item1= new ItemOfertaZilei("Supliment alimentar Zinc si Vitamina D3 Immuno C Solaray, 30 capsule Secom","In stoc","Livrat de: eMAG","-15% extra","26,99 lei");
        ItemOfertaZilei item2= new ItemOfertaZilei("Supliment alimentar Vitamin D3 2000UI Nature's Way, Secom 120 capsule moi","In stoc","Livrat de: eMAG","-15% extra","36,99 lei");
        ItemOfertaZilei item3= new ItemOfertaZilei("Pestisori gumati Omega 3 Moller's, cu aroma de lamaie verde si capsune, 36 jeleuri","In stoc","Livrat de: eMAG","-15% extra","45,99 lei");
        ItemOfertaZilei item4= new ItemOfertaZilei("Supliment alimentar Neuro Optimizer Jarrow Formulas, Secom 60 capsule","In stoc","Livrat de: Farmec","-15% extra","110 lei" );

        listaMedicamnte.add(item1);
        listaMedicamnte.add(item2);
        listaMedicamnte.add(item3);
        listaMedicamnte.add(item4);



        return listaMedicamnte;
    }
}
