package com.example.emag_4;

import android.os.Parcel;
import android.os.Parcelable;

public class Cont implements Parcelable
{

    private String nume;
    private String email;
    private String parola;

    public Cont() {
    }

    protected Cont(Parcel in) {
        nume = in.readString();
        email = in.readString();
        parola = in.readString();
    }

    public static final Creator<Cont> CREATOR = new Creator<Cont>() {
        @Override
        public Cont createFromParcel(Parcel in) {
            return new Cont(in);
        }

        @Override
        public Cont[] newArray(int size) {
            return new Cont[size];
        }
    };

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    @Override
    public String toString() {
        return "Contul este pentru " +
                "nume '" + nume + '\'' +
                ", email '" + email + '\'' +
                ", parola '" + parola + '\'' +
                '.';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nume);
        dest.writeString(email);
        dest.writeString(parola);
    }
}
