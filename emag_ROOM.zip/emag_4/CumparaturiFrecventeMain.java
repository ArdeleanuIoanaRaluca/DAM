package com.example.emag_4;

import androidx.appcompat.app.AppCompatActivity;


import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class CumparaturiFrecventeMain extends AppCompatActivity {

    ListView listView;
    ArrayList<Categorie> arrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cumparaturi_frecvente_main);

        listView = findViewById(R.id.listView);

        arrayList = new ArrayList<>();

        new JSONTasks().execute();



    }

    public class JSONTasks extends AsyncTask<String,String,String> {

        @Override
        public void onPreExecute(){
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... strings) {
            arrayList.clear();
            String result=null;
            try {
                URL url = new URL("https://jsonkeeper.com/b/RRQC");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.connect();

                if(conn.getResponseCode()==HttpURLConnection.HTTP_OK){
                    InputStreamReader inputStreamReader = new InputStreamReader(conn.getInputStream());
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    StringBuilder stringBuilder = new StringBuilder();
                    String temp;
                    while((temp= bufferedReader.readLine())!=null){
                        stringBuilder.append(temp);
                    }
                    result=stringBuilder.toString();
                } else {
                    result="error";
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        public void onPostExecute(String s){
            super.equals(s);

            try {
                JSONObject object = new JSONObject(s);
                JSONArray array = object.getJSONArray("data");

                for(int i=0;i<array.length();i++){
                    JSONObject jsonObject = array.getJSONObject(i);
                    String denumire=jsonObject.getString("denumire");

                    Categorie categorie = new Categorie();
                    categorie.setDenumire(denumire);

                    arrayList.add(categorie);
                    CategoriiProduseItem adapter = new CategoriiProduseItem(CumparaturiFrecventeMain.this,arrayList);
                    listView.setAdapter(adapter);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }
}