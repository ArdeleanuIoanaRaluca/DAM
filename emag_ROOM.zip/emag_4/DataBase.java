package com.example.emag_4;

import androidx.room.RoomDatabase;

@androidx.room.Database(entities = {Laptop.class}, version = 1, exportSchema = false)
public abstract class DataBase extends RoomDatabase {

    public abstract LaptopDao laptopDao();
}
