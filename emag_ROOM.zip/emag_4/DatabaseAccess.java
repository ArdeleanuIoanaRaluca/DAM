package com.example.emag_4;

import android.content.Context;


import androidx.room.Room;

public class DatabaseAccess {
    private DataBase database;

    private DatabaseAccess(Context context) {

        database= Room.databaseBuilder(context, DataBase.class, "dblaptop").allowMainThreadQueries().build();

    }

    private static DatabaseAccess instance;

    public static DatabaseAccess getInstance(Context context1){
        if(instance==null){
            instance=new DatabaseAccess(context1);
        }
        return instance;
    }

    public DataBase getDatabase(){
        return database;
    }

}
