package com.example.emag_4;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "laptopuri")
public class Laptop {
    @PrimaryKey(autoGenerate = true)
    private Integer id;
    @ColumnInfo(name = "denumire")
    private String denumire;
    @ColumnInfo(name = "descriere")
    private String descriere;
    @ColumnInfo(name = "pret")
    private Integer pret;

    public Laptop( String denumire, String descriere, Integer pret) {
        this.denumire = denumire;
        this.descriere = descriere;
        this.pret = pret;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public Integer getPret() {
        return pret;
    }

    public void setPret(Integer pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return  id +  '\n'+
                denumire + '\n' +
                 descriere + '\n' +'\n'+
                  pret
                ;
    }
}
