package com.example.emag_4;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;
@Dao
public interface LaptopDao {



    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(Laptop... laptop);

    @Delete
    void delete(Laptop laptop);

    @Query("select * from laptopuri")
    List<Laptop> getAll();

    @Query("SELECT * FROM LAPTOPURI WHERE PRET>1000")
    List<Laptop> getAllPret();

    @Query("SELECT * FROM LAPTOPURI WHERE PRET> :pret")
    List<Laptop> getAllPret(int pret);
}
