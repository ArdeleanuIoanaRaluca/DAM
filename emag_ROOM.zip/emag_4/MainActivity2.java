package com.example.emag_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity2 extends AppCompatActivity {

    LinearLayout btnVeziOferta,btnCumparaturiFrecvente,btnElectro,btnCopii,btnCasa,btnLibrarie;
     Button btnveziCategoriile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnveziCategoriile= findViewById(R.id.btnVeziCategorii);
        btnVeziOferta = findViewById(R.id.ofertaZilei);
        btnCumparaturiFrecvente = findViewById(R.id.cumparaturiFrecventeMain2);
        btnElectro=findViewById(R.id.electrocasniceMain2);
        btnCopii=findViewById(R.id.copiiMain2);
        btnCasa=findViewById(R.id.casaMain2);
        btnLibrarie=findViewById(R.id.librarieMain2);


        btnveziCategoriile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity2.this,CategoriiProduse.class);
                startActivity(intent);
            }
        });

        btnVeziOferta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, CategoriiProduse.class);
                startActivity(intent);
            }
        });
        btnCumparaturiFrecvente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity2.this,CategoriiProduse.class);
                startActivity(intent);
            }
        });
        btnElectro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity2.this,CategoriiProduse.class);
                startActivity(intent);
            }
        });
        btnCopii.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity2.this,CategoriiProduse.class);
                startActivity(intent);
            }
        });
        btnCasa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity2.this,CategoriiProduse.class);
                startActivity(intent);
            }
        });
        btnLibrarie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity2.this,CategoriiProduse.class);
                startActivity(intent);
            }
        });




    }
}