package com.example.emag_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class MainActivity_Laptop extends AppCompatActivity {
    private Laptop laptop;
    private LaptopDao dao;
    private ListView listViewlaptop;
    ArrayAdapter<Laptop>arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_laptop);
        listViewlaptop=findViewById(R.id.listViewlaptop);

       //laptop.setId(textView_id.getText().toString());
        //laptop.setDenumire(textView_denumire.getText().toString());
        //laptop.setDescriere(textView_descriere.getText().toString());







        Laptop laptop0=new Laptop("Laptop HP 255 G7 ","procesor AMD Ryzen™ 3 3200U pana la 3.50 GHz, 15.6\", Full HD, 8GB, 256GB SSD, Radeon™ Vega 3, Free DOS, Dark Ash Silver",1600);
        Laptop laptop1=new Laptop("Allview Allbook H","procesor Intel Celeron N4000 pana la 2.60 GHz, 15.6\", Full HD, 4GB, 256GB SSD, Intel UHD 600, Ubuntu, Grey",1500);
        Laptop laptop2=new Laptop("Laptop Gaming Lenovo IdeaPad 3 15ACH6","procesor AMD Ryzen 5 5600H pana la 4.2GHz, 15.6\", Full HD, IPS, 8GB, 512GB SSD, NVIDIA GeForce GTX 1650 4GB, No OS, Shadow Black",3200);

        dao=DatabaseAccess.getInstance(this).getDatabase().laptopDao();
        dao.insertAll(laptop1,laptop2);


        List<Laptop> lista1=dao.getAllPret();
        List<Laptop> lista2=dao.getAllPret(2000);
        dao.delete(laptop0);
        List<Laptop> lista3= dao.getAll();

        Log.v("operatii", lista1.toString());
        Log.v("operatii", lista2.toString());
        Log.v("operatii", lista3.toString());

        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista3);
        listViewlaptop.setAdapter(arrayAdapter);
    }


    }
