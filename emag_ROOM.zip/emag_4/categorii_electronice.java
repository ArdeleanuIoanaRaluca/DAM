package com.example.emag_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class categorii_electronice extends AppCompatActivity {
    LinearLayout btnLaptop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorii_electronice);

        btnLaptop=findViewById(R.id.laptopuri);
        btnLaptop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(categorii_electronice.this, MainActivity_Laptop.class);
                startActivity(intent);
            }
        });

    }
}